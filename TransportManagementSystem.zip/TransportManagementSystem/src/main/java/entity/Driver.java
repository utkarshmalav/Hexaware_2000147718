package entity;

public class Driver {
    private int driverId;
    private String name;
    private String status; // e.g., "Available", "Assigned"

    public Driver() {}

    public Driver(int driverId, String name, String status) {
        this.driverId = driverId;
        this.name = name;
        this.status = status;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Driver [driverId=" + driverId + ", name=" + name + ", status=" + status + "]";
    }
}